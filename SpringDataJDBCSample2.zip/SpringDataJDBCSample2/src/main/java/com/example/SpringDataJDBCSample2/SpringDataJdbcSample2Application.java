package com.example.SpringDataJDBCSample2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJdbcSample2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJdbcSample2Application.class, args);
	}

}
