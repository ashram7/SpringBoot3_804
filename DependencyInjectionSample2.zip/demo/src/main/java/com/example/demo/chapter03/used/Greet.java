package com.example.demo.chapter03.used;

public interface Greet {
    void greeting();
}
