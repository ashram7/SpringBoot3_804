package com.example.ValidationSample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidationSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
