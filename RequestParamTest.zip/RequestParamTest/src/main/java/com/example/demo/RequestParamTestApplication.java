package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RequestParamTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(RequestParamTestApplication.class, args);
	}

}
